Python 2.7.6 (default, Nov 10 2013, 19:24:24) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> ================================ RESTART ================================
>>> 
A body ocscilates with a frequency of 2Hz. What is its maximum vlocity in m/s?
Enter your answer : 1
It's wrong answer. Try again.
 Would you like the hint? (y/n)n
Enter your answer : 1.1
It's wrong answer. Try again.
 Would you like the hint? (y/n)n
Enter your answer : a
Invalid answer. please input number
Enter your answer : &
Invalid answer. please input number
Enter your answer : -1
It's wrong answer. Try again.
 Would you like the hint? (y/n)n
Enter your answer : 2.51
Your answer is 2.51 m/s
Correct. Go to the next question
>>> ================================ RESTART ================================
>>> 
A body ocscilates with a frequency of 2Hz. What is its maximum vlocity in m/s?
Enter your answer : 1
It's wrong answer. Try again.
 Would you like the hint? (y/n)y
maximum velocity = A*omega^2, omega = 2*pi*f
Enter your answer : 1
It's wrong answer. Try again.
 Would you like the hint? (y/n)n
Enter your answer : 
