Python 2.7.6 (default, Nov 10 2013, 19:24:24) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> ================================ RESTART ================================
>>> 
Determine the period of ocsillation of a simple pendulum of length 9.81m,given g = 9.81m/s^2
Choose ansewer from a, b, c, d
a = 6.28Hz
b = 0.455Hz
c = 17.96Hz
d = 0.056Hz
Enter your answer : d
It's wrong. Try it again.
if you want to check the hint, enter 'hint2'. 
Enter your answer : c
It's wrong. Try it again.
if you want to check the hint, enter 'hint2'. 
Enter your answer : b
It's wrong. Try it again.
if you want to check the hint, enter 'hint2'. 
Enter your answer : a
Correct. Go to the next page ans check your achievement.
>>> ================================ RESTART ================================
>>> 
Determine the period of ocsillation of a simple pendulum of length 9.81m,given g = 9.81m/s^2
Choose ansewer from a, b, c, d
a = 6.28Hz
b = 0.455Hz
c = 17.96Hz
d = 0.056Hz
Enter your answer : f
invalid answer
Enter your answer : b
It's wrong. Try it again.
if you want to check the hint, enter 'hint2'. 
Enter your answer : hint2
T = 2pi/omega = 2pi(L/omega)**1/2)
Enter your answer : a
Correct. Go to the next page ans check your achievement.
>>> ================================ RESTART ================================
>>> 
Determine the period of ocsillation of a simple pendulum of length 9.81m,given g = 9.81m/s^2
Choose ansewer from a, b, c, d
a = 6.28Hz
b = 0.455Hz
c = 17.96Hz
d = 0.056Hz
Enter your answer : b
It's wrong. Try it again.
if you want to check the hint, enter 'hint2'. 
Enter your answer : hint2
T = 2pi/omega = 2pi(L/omega)**1/2)
Enter your answer : a
Correct. Go to the next page ans check your achievement.
>>> 
