Python 2.7.6 (default, Nov 10 2013, 19:24:24) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> ================================ RESTART ================================
>>> 
Would you like to start quiz? y/ny
What is 2 + 3?a
What 6 x 6?b
Does this work?c
would you like to load answers? y/ny
{'answer_3': 'c', 'answer_2': 'b', 'answer_1': 'a'}
>>> ================================ RESTART ================================
>>> 
Would you like to start quiz? y/nn
would you like to load answers? y/ny
{'answer_3': 'c', 'answer_2': 'b', 'answer_1': 'a'}
>>> load_quiz()
{'answer_3': 'c', 'answer_2': 'b', 'answer_1': 'a'}
>>> 
